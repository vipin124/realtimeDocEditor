const express = require("express");

const Document = require("../models/Document");

const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// Get a document by ID

router.get("/:id", authMiddleware, async (req, res) => {

  try {

    const doc = await Document.findById(req.params.id);

    if (!doc) return res.status(404).send({ message: "Document not found" });

    res.send(doc);

  } catch (err) {

    res.status(500).send({ message: "Internal server error" });

  }

});

// Create a new document
router.post("/", authMiddleware, async (req, res) => {

  const { title, content } = req.body;

  try {

    const doc = new Document({ title, content, history: [] });

    await doc.save();

    res.status(201).send(doc);

  } catch (err) {

    res.status(500).send({ message: "Internal server error" });

  }

});

// Update a document

router.put("/:id", authMiddleware, async (req, res) => {

  const { content } = req.body;

  try {

    const doc = await Document.findById(req.params.id);

    if (!doc) return res.status(404).send({ message: "Document not found" });

    doc.history.push({ content: doc.content });

    doc.content = content;

    doc.lastEditedBy = req.user.id;

    await doc.save();

    res.send(doc);

  } catch (err) {

    res.status(500).send({ message: "Internal server error" });

  }

});

module.exports = router; 