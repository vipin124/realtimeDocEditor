import React, { useState, useEffect, useRef } from "react";

import { useParams, useNavigate } from "react-router-dom";

import ReactQuill from "react-quill";

import "react-quill/dist/quill.snow.css";

import axios from "../services/api";

function DocumentEditor() {

  const { id } = useParams(); // The document ID from the URL

  const [content, setContent] = useState("");

  const [title, setTitle] = useState("");

  const [isNewDocument, setIsNewDocument] = useState(false);

  const socketRef = useRef(null);

  const navigate = useNavigate();

  useEffect(() => {

    const token = localStorage.getItem("token");

    if (!token) navigate("/");

    const fetchDocument = async () => {

      try {

        // If `id` is not provided, treat this as a new document

        if (!id) {

          setIsNewDocument(true);

          return;

        }

        const response = await axios.get(`/document/${id}`, {

          headers: { Authorization: `Bearer ${token}` },

        });

        setTitle(response.data.title);

        setContent(response.data.content);

        setIsNewDocument(false);

      } catch (error) {

        alert("Failed to fetch document. Creating a new document.");

        setIsNewDocument(true);

      }

    };

    fetchDocument();

    // Establish WebSocket connection

    socketRef.current = new WebSocket("ws://localhost:3001");

    socketRef.current.onopen = () => {

      console.log("WebSocket connected");

    };

    socketRef.current.onmessage = (event) => {

      const data = JSON.parse(event.data);

      if (data.documentId === id) {

        setContent(data.content);

      }

    };

    return () => {

      socketRef.current.close();

    };

  }, [id, navigate]);

  const handleContentChange = (value) => {

    setContent(value);

    if (id) {

      socketRef.current.send(

        JSON.stringify({ documentId: id, content: value, userId: "currentUserId" })

      );

    }

  };

  const handleSaveNewDocument = async () => {

    const token = localStorage.getItem("token");

    try {

      const response = await axios.post(

        "/document",

        { title, content },

        { headers: { Authorization: `Bearer ${token}` } }

      );

      alert("Document saved successfully");

      navigate(`/editor/${response.data._id}`);

    } catch (error) {

      alert("Failed to save document");

    }

  };

  return (

<div>
<div>
{isNewDocument ? (
<>
<input type="text" placeholder="Enter document title" value={title} onChange={(e) => setTitle(e.target.value)}/>
<button onClick={handleSaveNewDocument}>Save Document</button>
</>) : (
<h1>{title}</h1>
)}
</div>
<ReactQuill value={content} onChange={handleContentChange} />
</div>

  );

}

export default DocumentEditor; 